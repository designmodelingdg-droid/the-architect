# Skills de DMA: web, animaciones y video

Carpeta `skills/`: cada subcarpeta es una skill de Claude Code (archivo SKILL.md más sus recursos).
Para instalarlas, copia las carpetas a `~/.claude/skills/` (o a `.claude/skills/` dentro de un repositorio) y reinicia la sesión.

| Skill | Para qué sirve |
|---|---|
| `app-dma` | Arquitecto de aplicaciones DMA: de la idea al blueprint y a la app construida bloque por bloque (login, base de datos, panel). |
| `carrusel-studio` | Director creativo y diseñador senior que produce carruseles de Instagram publishables de 8 a 12 slides, construyendo un sistema visual desde cero ada |
| `clips-clases-vimeo` | Saca fragmentos virales de las clases grabadas de DMA en Vimeo (Gabriel y docentes) y los edita como reels de prueba social para que la gente vea lo q |
| `director-video-dma` | Director y editor de video de DMA: recibe el crudo (de Daniela o Dayana), decide estilo y ganchos, edita, revisa y entrega a la matriz. Usar con /dire |
| `estilos-reels-dma` | Catálogo de estilos de edición de videos DMA con nombre (explicativo pizarra, tutorial, demo de recurso, vlog, concepto 3D, publicitario, testimonio |
| `explicacion-isometrica-dma` | Videos explicativos DMA en dibujo isométrico técnico (estilo Anatomy): piezas que se arman, desarman y se encienden al ritmo de la voz de Gabriel, e |
| `landing-agenda` | Página «gracias + agenda» que sigue al formulario de una landing de producto DMA (calendario de cita). |
| `landing-evento` | Genera landing pages HTML completas para eventos, workshops y webinars de Design Modeling Academy (DMA). Úsalo SIEMPRE que el usuario quiera crear o  |
| `landing-producto` | Genera landing pages HTML completas para programas robustos de Design Modeling Academy (DMA): Másters, Diplomados, Certificaciones y cualquier produc |
| `leadmagnet-app` | Construye lead magnets interactivos completos para Design Modeling Academy (DMA) — calculadoras de ingeniería, mini-apps y herramientas gratuitas d |
| `patrones-virales-dma` | Patrones que hacen funcionar los videos y anuncios de DMA en el nicho BIM + IA (investigación del 8-oct-2026): ganchos, ritmo, CTA con palabra, ficha |
| `reel-animacion-explicativa` | Edición de reels y pautas de DMA con animaciones explicativas: pizarra de cuaderno que se dibuja sobre Gabriel, subtítulo en barra cobre y cierre co |
| `reel-remotion-dma` | Edita reels y videos verticales de DMA con Remotion: subtítulos palabra por palabra con Whisper local, cortes de pausas revisables, palabras clave an |
| `video-a-skill` | Convierte un video (tutorial de YouTube, reel, clase grabada) en una skill reutilizable: lo mira con /watch, extrae el método paso a paso y propone l |
| `web-dma` | Manual de los sitios web de DMA: sistema visual, Next 16 + Tailwind 4, movimiento con criterio, SEO, legibilidad para agentes, Sharp CRM, corte de dominio e indexación. |

Exportado el 2026-11-06 desde la sesión de la web de Design Modeling.
