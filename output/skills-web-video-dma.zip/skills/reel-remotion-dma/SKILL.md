---
name: "reel-remotion-dma"
description: "Edita reels y videos verticales de DMA con Remotion: subtítulos palabra por palabra con Whisper local, cortes de pausas revisables, palabras clave animadas con la marca DMA y export MP4 1080×1920."
---

# Reel con Remotion · Design Modeling Academy

Flujo de edición basado en la guía "Edita tu primer reel con Codex + Remotion" (Héctor Suárez), adaptado a Claude y a la marca DMA. Responde siempre en español.

Si en la conversación o en las skills existe otra skill de videos de DMA (estilo, intro/outro, CTA, logos), sus reglas de marca mandan; esta skill aporta el motor técnico (Remotion + Whisper) y el método de revisión por etapas. El catálogo de estilos y la «Caja de efectos» (vidrio, reflejo, texto letra a letra, flash, B-roll «Dopamina») están en `estilos-reels-dma`.

## Reglas de oro
- Nunca modificar el archivo original: copiarlo a `public/original.mp4` dentro del proyecto.
- No inventar palabras ni tiempos en subtítulos: siempre salen de la transcripción.
- Todo local y gratis. Avisar antes de usar cualquier servicio de pago o subir el video a terceros.
- Etapas con revisión: no exportar el final hasta que Dayana apruebe la vista previa (salvo urgencia, p. ej. una historia con oferta que vence hoy: entonces se entrega directo y se ajusta después).
- Un cambio por vuelta (subtítulos, luego cortes, luego animaciones), así es fácil evaluar.
- Nada tapa la cara de Gabriel: textos, tarjetas e íconos van por debajo del mentón o a los lados.

## 0. Preparar el entorno (una vez por sesión)
```bash
which ffmpeg ffprobe node || echo FALTA
pip install -q --break-system-packages faster-whisper yt-dlp
npx -y skills add remotion-dev/skills --yes   # skills oficiales de Remotion (create, captions, markup, render, studio)
```
Si el instalador pregunta agente, elegir Claude Code. Después leer `remotion-best-practices` y, según la etapa, `remotion-create`, `remotion-captions`, `remotion-markup` (incluye silence-detection.md, text-highlights.md, video-editing.md, cropping.md) y `remotion-render`.

Atajo probado (1-nov-2026): copiar `video-recursos/plantillas/motion-dma/` del repo de la matriz a una carpeta de trabajo y hacer `npm i` (~40 s); ya trae Remotion, `@remotion/google-fonts` y el kit de marca. Videos de iPhone 4K a 60 fps: bajarlos primero a 1080×1920 y 30 fps con ffmpeg antes de cortar (cortar el 4K directo se queda sin memoria). Si faster-whisper falla al abrir el video (error de `av.open`), extraer antes el audio a WAV 16 kHz mono y pasarlo como arreglo de numpy.

## 1. Revisar el video fuente
`ffprobe` → reportar duración, resolución, orientación, fps y si hay pista de audio. Si el video es horizontal, preguntar: recortar a 9:16 centrado en la cara, o plano completo con fondo navy desenfocado. Nunca estirar.

## 2. Crear el proyecto
```bash
npx create-video@latest --yes --blank --no-tailwind reel-<slug>
cd reel-<slug> && npm i
```
Composición `Reel` de 1080×1920, fps del original, duración calculada desde el video (`calculateMetadata`). Usar `<Video>` de `@remotion/media` con `premountFor={fps}`. Primera vista previa: solo el clip encuadrado, sin efectos — renderizar 3 fotogramas (`npx remotion render Reel out/frames --frames=0,<mitad>,<final> --image-format=png`) y enviarlos para validar encuadre.

## 3. Transcribir con tiempos por palabra (Whisper local, CPU)
La GPU de `@remotion/whisper-webgpu` no existe en la nube; usar faster-whisper:
```python
from faster_whisper import WhisperModel
import json
m = WhisperModel('small', device='cpu', compute_type='int8')  # 'medium' si hay términos técnicos difíciles
segs, _ = m.transcribe('public/original.mp4', language='es', word_timestamps=True, vad_filter=True,
    initial_prompt='Design Modeling Academy, BIM, Revit, Dynamo, Navisworks, Robot Structural, SAP2000, Máster BIM+IA, Autodesk')
caps = [{'text': (' ' if i else '') + w.word.strip(), 'startMs': int(w.start*1000), 'endMs': int(w.end*1000),
         'timestampMs': int((w.start+w.end)*500), 'confidence': round(w.probability,3)}
        for i, w in enumerate(x for s in segs for x in s.words)]
json.dump(caps, open('public/captions.json','w'), ensure_ascii=False, indent=1)
```
Formato = tipo `Caption` de `@remotion/captions`. Marcar para que Dayana confirme las palabras con `confidence < 0.6` y los nombres propios. Si ella da un .srt o guion, usarlo y solo alinear tiempos. Whisper escribe las cifras como dígitos: al sincronizar gráficos con palabras, buscar «5», «120», no «cinco». Los precios salen partidos («19» + «,99»): unirlos en una sola palabra de subtítulo.

## 4. Proponer cortes (sin aplicarlos aún)
Seguir `silence-detection.md` (loudnorm → silencedetect adaptativo, d=0.5). Cruzar con los tiempos de palabras: solo cortar pausas > 0.6 s y repeticiones/arranques fallidos claros. Dejar 80–120 ms de colchón antes y después de cada palabra; conservar respiraciones naturales. Entregar tabla: `# | inicio | fin | motivo | texto antes/después`. Aplicar solo lo aprobado, con un `<Video>` por tramo dentro de `<Series>` (cada clip editable en Studio) y re-mapear los tiempos de subtítulos al nuevo timeline. Los empalmes de un plano fijo se disimulan con un cambio de encuadre (zoom 1,0 ↔ 1,08) o un destello.

## 5. Subtítulos y énfasis (estilo DMA)
- Páginas de 1–3 palabras (`createTikTokStyleCaptions`, combineTokensWithinMilliseconds ≈ 900), máximo 2 líneas.
- **Tipografía del perfil de Instagram (Dayana, 1-nov-2026: «debes usar la de Design»; escrita en el manual de marca, línea «VIDEOS Y REDES»):** Bebas Neue para subtítulos y palabras clave (90–120 px, es condensada), Montserrat 700-900 para textos de apoyo (vía `@remotion/google-fonts/BebasNeue` y `/Montserrat`), blanco con contorno o sombra navy #0d1e3a. No usar Overpass, Nunito, Space Grotesk ni Anton.
- Palabra activa o clave: naranja del perfil #E8893A con escala sutil 1→1.08 usando `spring`/`interpolate`. Nada de rebotes continuos ni animaciones CSS.
- Destacar solo 1 palabra clave cada 3–5 s (cifras, nombres de software, beneficios).
- Zonas seguras Reels: dejar libres ~230 px arriba y ~380 px abajo y ~120 px a la derecha; subtítulos centrados en el tercio inferior sin tapar la cara.
- Historias: 250 px libres arriba (barra del perfil) y abajo (barra de respuesta); si va con sticker de enlace, dejar el hueco (y ≈ 1590–1720) y una flecha «TOCA EL ENLACE»; si se publica por la API (sin stickers), usar «Responde PALABRA» en su lugar.
- Música baja bajo la voz y sin silencios largos (reglas de `estilos-reels-dma`). B-roll de terceros sin licencia («Dopamina») solo en orgánico.

## 6. Revisar
Renderizar fotogramas de inicio, mitad y final + un preview corto de los primeros 10–15 s (`--frames=0-449` o `--scale=0.5`) y enviarlos. Revisar: texto = voz, ningún corte deja palabras a medias, cara visible, nada choca con la interfaz de IG. Para un corte brusco: recuperar 4–8 fotogramas del original alrededor del corte y ajustar audio y subtítulos juntos; mostrar antes/después.
- No renderizar mientras corre una voz con IA (Chatterbox ocupa ~4 GB de RAM y Chrome de Remotion se cae por tiempo de espera). Renderizar con `--concurrency=2`.

## 7. Exportar (solo con aprobación)
```bash
npx remotion render Reel out/reel-editado-v1.mp4 --codec=h264 --audio-codec=aac
ffprobe out/reel-editado-v1.mp4   # verificar 1080x1920, duración y pista de audio
```
Pasada final con ffmpeg: `yuv420p` (`scale=in_range=full:out_range=tv`), `loudnorm` −14 LUFS, AAC 192k, `-movflags +faststart`. Enviar el MP4 con SendUserFile y conservar el proyecto editable. Versiones siguientes: v2, v3… Si el disco va justo, borrar los `out/*.mp4` intermedios tras entregar.

## 8. Publicar historias (opcional, con el «sí» de Dayana)
Flujo **Publicar historia** del repo de la matriz (`.github/workflows/publicar-historia.yml` + `scripts/publicar_historia.py`, token del System User «Design Modeling - Ads CLI»): sube el MP4 a una URL pública (rama `vimeo-clips`), corre `modo=previa` (revisa 9:16, 3–60 s, códec, peso y da la huella) y, solo tras el «sí», `modo=publicar` con esa huella (red instagram, facebook o ambas; `a_las` para programar hasta ~6 h; más lejos, se agenda el lanzamiento). Por la API no hay stickers.

## Si algo falla
No avanzar de etapa. Explicar la causa probable en simple, revisar archivo → carpeta → dependencias, aplicar la corrección mínima y re-probar solo ese paso.