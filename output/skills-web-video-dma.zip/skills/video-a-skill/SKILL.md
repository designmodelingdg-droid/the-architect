---
name: "video-a-skill"
description: "Convierte un video (tutorial de YouTube, reel, clase grabada) en una skill reutilizable: lo mira con /watch, extrae el método paso a paso y propone la skill lista para guardar."
---

# Video → Skill (la forja)

Basado en la guía "De videos a skills" de tododeia. Responde en español.

## 1. Mirar el video
Cargar la skill `watch` y ejecutarla sobre la URL o archivo. Empezar barato:
- Tutorial hablado: `--detail transcript` (sin descargar video).
- Si el método depende de lo que se ve en pantalla (clics, interfaces, código, edición): `--detail balanced --resolution 1024`, y `--start/--end` para la parte relevante.
- Video local sin subtítulos y sin llave de Whisper API: transcribir con faster-whisper local (`pip install --break-system-packages faster-whisper`, modelo `small`, `language='es'`, `word_timestamps=True`) y pasar el texto junto con los fotogramas.
- Videos largos públicos de YouTube: si existe `GEMINI_API_KEY`, se puede usar Gemini para el resumen largo; si no, trocear por `--start/--end`.

## 2. Extraer el método
Devolver a Dayana, antes de escribir la skill:
- Qué resuelve y cuándo usarlo (disparadores reales, en sus palabras).
- Herramientas y requisitos (instalaciones, llaves, costos).
- Pasos numerados con comandos/prompts exactos tal como aparecen en el video (citar minuto).
- Criterios de calidad y errores comunes que el autor menciona.
- Lo que NO está claro en el video (no inventarlo; marcarlo como pendiente).
Una pregunta como máximo si algo cambia el resultado (p. ej. adaptarlo a DMA o dejarlo genérico).

## 3. Escribir la skill
Seguir el formato de `skill-creator`: frontmatter con `name` en kebab-case y `description` de una línea que diga cuándo usarla; cuerpo con pasos imperativos, comandos exactos, reglas de oro y sección "si algo falla". Si es para DMA, aplicar la marca (navy #0d1e3a/#004A70, cobre #c8721e/#D78631; Inter, Space Grotesk, Nunito, Montserrat) y el tono de Dayana. Atribuir la fuente (autor + URL) al inicio.

## 4. Probarla y proponerla
- Probar los disparadores: escribir 3 frases con las que Dayana pediría esto y confirmar que la descripción las cubre.
- Si la skill ejecuta comandos, correr una prueba mínima en el workspace y corregir.
- Proponerla con la herramienta `propose_skills` (no entregar archivos SKILL.md sueltos). Si mejora una skill existente, leer su SKILL.md actual y proponer el archivo completo actualizado.