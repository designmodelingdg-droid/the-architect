---
name: "patrones-virales-dma"
description: "Patrones que hacen funcionar los videos y anuncios de DMA en el nicho BIM + IA (investigación del 8-oct-2026): ganchos, ritmo, CTA con palabra, ficha de anuncios y variantes. Leer antes de editar o guionizar cualquier reel, pauta o video de valor de DMA."
---

# Patrones virales y de pauta DMA

Sale de la investigación «Edición ganadora en el nicho BIM + IA» del 8-oct-2026. El informe completo está en el repo `meta-ads-dashboard.html`, en `matriz-viral/matriz/EDICION-GANADORA-NICHO.md`, y los datos en `matriz-viral/fuentes/edicion-ganadora/`. La muestra: 83 TikTok, 120 anuncios activos de la Biblioteca de Meta (54 con más de 90 días y 32 con más de 180) y 11 reels de Instagram, todos mirados cuadro a cuadro. Responde en español.

Esta skill manda sobre el gancho, el ritmo, el CTA y las variantes. El aspecto visual de cada tono está en `estilos-reels-dma`, y el motor en `reel-remotion-dma`.

## Cómo leer los datos
- Las vistas de TikTok no dicen nada de ventas.
- **La mejor señal de venta es cuánto tiempo lleva activo un anuncio:** nadie paga 300 días un anuncio que no vende.
- La duración no separa a los ganadores: la mediana ronda los 50 s en ganadores y en el resto. Lo que separa es **el gancho escrito y que algo cambie en pantalla cada 1–3 s**.

## Reglas para todo video (valor o pauta)
1. **Gancho en los primeros 2 segundos, dicho y escrito arriba, fijo todo el video** (o hasta que entre la pizarra o la pantalla). Tipos que funcionan, siempre con datos reales:
   - **Miedo o provocación:** «¿La IA acaba de reemplazar a los modeladores BIM?».
   - **Número grande y concreto:** «Le pedí una losa de 6 m y encontré 2 errores».
   - **Promesa sin barrera:** «Conectar Revit con IA sin saber programar».
   - **Reto visual:** «Le pedí a la IA que modele esto en Revit».
   - **Dolor del ingeniero:** «Tu estructura puede cumplir resistencia y ser inhabitable».
2. **Nada quieto más de 2–3 s:** subtítulo, captura, corte, zoom o dibujo.
3. **Subtítulos de 1–2 palabras** sincronizados palabra por palabra, con la palabra clave en caja de color: cobre `#D78631`, que es el naranja de marca aprobado (la investigación lo llama naranja `#E8893A`; se usa el cobre aprobado).
4. **CTA con palabra clave viva.** Sin palabra no hay comentarios: los ganadores sin palabra sacan 0.1–1.2 comentarios por cada 1.000 vistas, y uno con «Comenta BIM» saca 18.7. Antes de exportar, confirmar en la matriz que la palabra tiene **una sola** automatización que la contesta (GHL u OpenReply).
5. **Marca de criterio DMA:** decir qué hace la IA y qué no, con la versión y la licencia cuando dependa de eso. Es la diferencia frente a quien promete magia.
6. **Persona real** (Gabriel, docentes, alumnos), nunca avatar. Si algo se genera con IA (imágenes 3D, voz, doblaje), se rotula y, en pauta, se marca como contenido generado con IA en Meta.
7. **Mostrar la prueba:** el recurso real, el modelo contra la obra, resultados de alumnos o la clase real.

## Tema que más rinde hoy
**Conectar la IA a Revit (MCP):** de los 12 TikTok más vistos, 6 son de eso (uno sacó 87 veces la mediana de su cuenta). Al tocarlo hay que decir siempre que **el conector oficial de Revit 2027 es de solo lectura**: lo que «modela» lo hacen plugins de terceros. Así se mantiene el gancho sin prometer lo que no es.

## Las tres plantillas que dominan el nicho
| Plantilla | Cómo es | Duración | En DMA |
|---|---|---|---|
| **Tres bandas** | Titular fijo arriba (2 líneas) + pantalla real al centro + banda fija abajo con el CTA o la oferta; subtítulos entre la pantalla y la banda | 18–35 s | Estilo «demo de recurso» |
| **Presentador + B-roll** | Cara real con el titular encima (blanco + color); cortes a pantalla o B-roll cada ~2 s; subtítulo de 1 palabra en caja | 30–50 s | Estilos «publicitario» y «explicativo» (pizarra) |
| **Tutorial con pasos** | Pantalla con «PASO 1 / 2 / 3» grandes y logos del software que entran | 30–60 s | Estilo «tutorial» |

## Ficha de anuncios (pauta pagada, 30–45 s, 9:16)
Sale de los anuncios que llevan meses activos (Taller Lap: 293–432 días con 3–4 variantes; Arq. Luis Raez: 340 días; CAPCI Perú; Julia Instalações BIM).

| Tramo | Qué va |
|---|---|
| 0–3 s | Gancho escrito arriba, fijo (2 líneas: blanco + cobre claro), dicho por Gabriel en el primer segundo. Número o dolor concreto |
| 3–25 s | Prueba en pantalla dividida: arriba, Revit/Robot real o la demo de la IA; abajo, Gabriel (en obra o en su escritorio). Algo cambia cada 1–3 s. Variante: B-roll en mosaico (2–3 imágenes apiladas: render, Revit, plano) |
| Todo el video | **Banda fija abajo con la oferta** (workshop, recurso gratis o programa, sin el precio del Máster) y subtítulos de 1–2 palabras en caja cobre entre la pantalla y la banda |
| 25–40 s | Una frase de criterio (lo que la IA no hace, o para quién NO es) y el CTA: «Comenta PALABRA» o el botón del anuncio. Logo 1–2 s |
| Variantes | **3–4 versiones del mismo cuerpo con distinto gancho.** Se apagan las que no rinden; no se produce un video nuevo por cada idea |

Lo que tienen en común los anuncios que duran meses:
1. Persona real.
2. La oferta visible de principio a fin.
3. Una prueba visual (modelo contra obra, resultados de alumnos, demo).
4. Son explicativos, no frenéticos: 30–60 s, con un plano largo del presentador y cortes a pantalla.
5. Varias variantes activas a la vez.

Al entregar una pauta, exportar las 3–4 variantes de gancho con nombre de archivo claro (`pauta-<tema>-gancho-a.mp4`, `-b`, `-c`) y una línea con el texto de cada gancho.

## Ficha de videos de valor
- **Demos de software:** «Tres bandas», 20–35 s.
- **Gabriel explicando:** `reel-animacion-explicativa` (pizarra), con el titular de 2 líneas en el gancho.
- **Tutoriales:** «PASO 1 / 2 / 3» grandes. Como mucho un meme de reacción, y solo si encaja con la marca.
- **Prueba social:** testimonios y fragmentos de clase (estilo 7 de `estilos-reels-dma`, clips con `clips-clases-vimeo`).

## Checklist antes de entregar cualquier video
- [ ] El gancho se ve escrito y se oye en el primer segundo.
- [ ] Ningún tramo de más de 2–3 s sin cambio visual.
- [ ] Subtítulos de 1–2 palabras, con la palabra clave en caja cobre.
- [ ] Hay una prueba real (recurso, clase, alumno, modelo).
- [ ] Hay una frase de criterio (qué sí y qué no).
- [ ] La palabra del CTA está en la matriz, con una sola automatización.
- [ ] Si es pauta: banda de oferta fija, 3–4 variantes de gancho, sin precio del Máster, contenido IA marcado.
- [ ] Datos técnicos revisados (normas, versiones); los números de ejemplo van rotulados.