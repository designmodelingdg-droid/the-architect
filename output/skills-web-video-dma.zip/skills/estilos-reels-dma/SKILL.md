---
name: "estilos-reels-dma"
description: "Catálogo de estilos de edición de videos DMA con nombre (explicativo pizarra, tutorial, demo de recurso, vlog, concepto 3D, publicitario, testimonio y clase, motion graphics, pizarra dibujada con voz IA, Gabriel motion cromado para pauta, ruta de producto, cromado con cámara, motion IA, isométrico), caja de efectos (vidrio, reflejo, texto letra a letra, flash, B-roll dopamina) y comandos de efectos de Higgsfield (/tier-list, /glass-graph, /over-the-shoulder, /freeze-frame, /text-behind, /grade-wipe): cuándo usar cada uno y cómo se edita. Usar junto con reel-remotion-dma y patrones-virales-dma en cualquier reel o pauta de DMA."
---

# Estilos de edición DMA

Dayana pide los videos por estilo y por tono. Cada estilo de abajo sale de reels reales de DMA que ella eligió como modelo (7-oct-2026) o de referencias externas ya aprobadas. Se adapta el lenguaje de edición de las referencias externas, nunca su identidad: no se copian textos, logos, caras, frases ni portadas de otros creadores. Responde siempre en español.

**Siempre, con cualquier estilo:**
- Motor y flujo: `reel-remotion-dma` (Remotion + Whisper + ffmpeg); el corte de voz, con `/editar` (ver «Primer paso» abajo).
- Reglas de gancho, ritmo, CTA y variantes: `patrones-virales-dma`. Leerla primero; manda sobre los detalles de cada estilo.
- Paleta de marca, aprobada por Dayana: cobre `#D78631` (barras y cajas), naranja del perfil `#E8893A` (palabras clave y grandes, con contorno navy), navy `#0D1E3A`. Rojo marcador `#E5252A` solo para señalar. Nunca amarillo.
- **Tipografía = la del perfil de Instagram @design_modeling_dg (Dayana, 1-nov-2026: «debes usar la de Design tipo así», mostrando el grid del perfil; quedó escrita en el manual de marca de la app de contenido, línea «VIDEOS Y REDES»):** **Bebas Neue** para títulos, palabras grandes, cromados, subtítulos y códigos (como «HOLA, SOY GABRIEL» o «¿LA IA TE VA A REEMPLAZAR?»), blanco con un degradado leve a `#D3D8DF` y las palabras clave en el naranja del perfil `#E8893A`; **Montserrat 700-900** para textos de apoyo, kickers, chips y etiquetas. Es la misma pareja de las plantillas de `imagen-marca-dma` (`plantilla-perfil/fonts/`). En Remotion: `@remotion/google-fonts/BebasNeue` y `/Montserrat`. Bebas es condensada: subir el tamaño ~30 % respecto a una letra normal. NO usar Overpass ni Nunito (son de la web; el 31-oct se probaron en video y no gustaron), ni Anton; Kalam solo si Dayana lo pide. Cromado sí, pero suave (blanco→gris claro, naranja→naranja oscuro), para que se parezca al perfil.
- Gabriel siempre a 1.2× (máximo 1.25×), sin pausas de más de 0.15–0.2 s.
- **Nada tapa la cara de Gabriel** (Dayana, 31-oct-2026): tarjetas, íconos, cromados y subtítulos van por debajo del mentón o a los lados, nunca encima del rostro. Comprobarlo en la hoja de contacto con la cara marcada.
- **Sin silencios:** ninguna pausa de más de ~0,1 s dentro de la voz ni huecos largos entre frases (también en las voces con IA: `silenceremove` de pausas > 0,1 s a −32 dB dejando 0,06 s, y 0,1 s entre frases).
- **Música:** siempre de fondo y libre de reclamos: la generada por código — `video-recursos/scripts/musica_original.py` (lo-fi suave de 4 acordes) para explicativos, o `musica_energica.py` (electrónica a 137 BPM con subida y drop, más atractiva; Dayana, 22-oct-2026) para pauta y piezas rápidas, con los cortes en el golpe del compás — a ~−30 LUFS bajo la voz (`volume=0.13`) o algo más alta si no hay voz, o la biblioteca de música de Instagram al publicar. Nunca canciones comerciales ni la música de Brag sin licencia.
- Nunca el precio del Máster en pantalla.
- **Portada siempre** (pedido de Dayana, 19-oct-2026): el primer fotograma de todo video es una portada de marca con el tema en grande y lo que se va a ver (p. ej. «5 TIPOS DE CIMENTACIÓN» con tres de los tipos dibujados), sin subtítulo ni marcador encima. Se entrega además como `<video>-portada.jpg` (fotograma 0) para que Daniela la suba como miniatura. En la portada no cuenta la regla de «nada quieto»: a partir de ~0,4 s ya algo se mueve sobre ella. **Tiene que verse completa en la cuadrícula del perfil** (Dayana, 19-oct-2026): Instagram recorta el reel a 3:4 (1080×1440, de y = 240 a 1680), así que título, dibujos y textos de la portada van entre y ≈ 300 y 1580, con margen; el logo del pie queda fuera y no importa. Con Gabriel en cuadro, el texto de la portada llega como máximo a la altura de su barbilla. Se comprueba recortando el fotograma 0 a 3:4 y se entrega también ese recorte (`<video>-portada-3x4.jpg`).

## Catálogo (cómo lo pide Dayana → qué hacer)

| # | Nombre que usa Dayana | Cuándo | Modelo |
|---|---|---|---|
| 1 | «explicativo», «con animaciones explicativas», «estilo pizarra» | Gabriel explica a cámara un concepto, error o criterio | Skill `reel-animacion-explicativa` (aprobada con los reels de derivas e IA) |
| 2 | «tutorial», «paso a paso» | Se enseña a hacer algo en el software (IA + Revit, Robot, Dynamo) | DdkrVGsOcLz, Da1ABdbJ7ji |
| 3 | «demo de recurso», «enseñar la herramienta», «lead magnet» | Se muestra cómo se usa algo que regalamos o incluimos (tutor IA, calculadoras, plantillas) | Ddrj9bGpZXK + plantilla «Tres bandas» |
| 4 | «vlog», «evento» | Visitas, jurados, congresos, alianzas, viajes | DbwXlNAipv7 |
| 5 | «concepto 3D», «explicativo con IA» | Un tema técnico explicado con imágenes 3D generadas, sin presentador | DaTwRB3pCN1 |
| 6 | «publicitario», «pauta», «anuncio» | Venta o captación pagada, o un gancho fuerte de valor | DXhGhxYAOoz, DXPEqa7Cki0 + ficha de anuncios de `patrones-virales-dma` |
| 7 | «testimonio», «clase», «lo que damos» | Prueba social: alumnos, certificados, fragmentos de clases reales | DTJlMHiCczr, DRuToFvkXTk, DRhcAwNFYXJ, DKLRg_ks6tk, DKIoScIhCRr, DXFN853gdXg + skill `clips-clases-vimeo` |
| 8 | «motion graphics», «animado», «Brag», «lanzamiento» | (a) Gabriel hablando con gráficas animadas alrededor y detrás de él; (b) pieza 100 % animada de un recurso o web, sin presentador | Guía tododeia «Motion graphics con Opus 5.5» + Brag (`latent-spaces/brag`, modo brag-slim) |
| 9 | «pizarra dibujada», «dibujo a mano», «como los de cimentaciones», «con la voz explicando» | Explicar un concepto técnico (tipos, partes, procesos) sin grabar a nadie | «5 tipos de cimentación» y «Simbología de niveles» (19-oct-2026), plantilla `video-recursos/plantillas/pizarra-dibujada/` |
| 10 | «motion cromado», «los motions brutales», «como el del contador», «pauta con Gabriel» | Pauta con Gabriel a cámara: gancho de venta o de valor con mucho golpe visual | Demo «5 scripts de Dynamo» (22-oct-2026), plantilla `video-recursos/plantillas/gabriel-motion-cromado/` |
| 11 | «ruta», «mapa del programa», «como el del Máster», «tipo Duolingo» | Explicar un producto completo (Máster, Diplomado, Especialización, Colección) como un camino de pasos hasta la meta, para pauta y para el mensaje de bienvenida | «La ruta del Máster» v3 fusión, Colección Autodesk con IA, Especializaciones, Acero, Diplomado BIM en Cálculo (oct-2026); código en `video-recursos/plantillas/motion-dma/` |
| 12 | «cromado con cámara», «como el anuncio de los zooms», «ángulos y flash» | Pauta o historia con tomas reales de Gabriel (workshop, clase, oficina, celular) a las que se les da movimiento de cámara, texto cromado e íconos o chips | Referencia IG DeuJ5Z5A3YH; «Workshop cromado v2» (31-oct-2026) e historia «Halloween últimas horas» (1-nov-2026) |
| 13 | «motion con IA», «ícono que entra flotando», «como los prompts de la comunidad» | Gancho de 2–4 s o B-roll de producto: un objeto de marca (ícono, app, certificado) que entra y se arma con interfaz a su alrededor | Doc «Prompts de motion graphic con IA» (comunidad de editores, 31-oct-2026) |
| 14 | «isométrico», «que se arme y desarme», «estilo Anatomy» | Explicar una pieza técnica (unión, cimentación, armado) por partes que se separan y se encienden con la voz | Skill `explicacion-isometrica-dma` (prueba unión viga-columna, 30-oct-2026) |
| 15 | «/tier-list», «/glass-graph», «/over-the-shoulder», «/freeze-frame», «/text-behind», «/grade-wipe», «los comandos de Higgsfield» | Gabriel a cámara en vertical (≤ 60 s) y se quiere un efecto rápido sobre su toma: ranking, gráfica que sube, antes/después, congelado con su nombre, palabra detrás de la cabeza, color de cine | Guía tododeia «Higgsfield commands» (5-nov-2026); ver «Efectos Higgsfield» abajo |

Los modelos son reels de instagram.com/reel/<ID>/ y se bajan con `yt-dlp` (uno por uno; el listado del perfil está bloqueado con 429). Si Instagram bloquea la descarga (429 o redirección al login) y Apify no responde, se le pide a Dayana que adjunte el video. YouTube suele pedir inicio de sesión desde la nube: si un enlace de YouTube no baja, pedir el video o un reel equivalente. Si un estilo no está claro con el material que llega, se elige por el contenido: pantalla sin cara → 2; Gabriel explicando → 1; Gabriel vendiendo → 6 (o 10/12 si es pauta y hay que destacar); tomas sueltas de un evento → 4; concepto técnico sin nadie grabado → 9 o 14; producto entero con sus módulos → 11.

---

## 2 · Tutorial
La voz de Gabriel va en off sobre la grabación de pantalla real, recortada y ampliada a vertical. Duración: 40–85 s; si pasa de 60 s se parte en «parte 1 / parte 2».

- **Pantalla:** la zona útil del escritorio ocupa todo el 9:16, con zoom suave hacia donde está la acción (el prompt, la respuesta, el botón). Se pasa a una vista 3D de Revit cuando aparece el resultado.
- **Subtítulo:** 2–4 palabras en MAYÚSCULAS, Bebas Neue de unos 84 px, blanco con contorno navy, centrado a media altura. La palabra clave va en caja cobre.
- **Transiciones:** zoom radial con desenfoque (0.25 s) al cambiar de app o de paso, y un corte seco en el resto.
- **Pasos:** «PASO 1 / 2 / 3» en Bebas Neue grande, solo, durante 0.6 s antes de cada paso. El prompt se resalta con un recuadro rojo dibujado.
- **Frase de criterio** a mitad o al final: «la IA no reemplaza el criterio; acelera el proceso». Va escrita grande.
- **Cierre:** el resultado en Revit + «Comenta PALABRA».
- Base técnica: el Estilo A de abajo.

## 3 · Demo de recurso (lead magnet o herramienta incluida)
Dos variantes, según el material:

- **Cámara a la pantalla (como Ddrj9bGpZXK):** el celular graba la laptop o el iPad mientras se usa la herramienta y Gabriel habla en off, con energía («¡Colegas, esto es una locura!»). Subtítulos de 2–4 palabras abajo a la izquierda, blanco sobre cajas cobre por línea (estilo resaltador). Se corta a cada respuesta nueva de la herramienta.
- **«Tres bandas» (lo que más gana en IA + Revit, 20–35 s):** titular-pregunta fijo arriba en 2 líneas (blanco + naranja), pantalla real al centro y banda cobre fija abajo con «Comenta PALABRA» u «Gratis para alumnos del Diplomado». Subtítulos de 1–2 palabras entre la pantalla y la banda.

**Siempre:** la herramienta real (capturas o grabación de la que vive en `meta-ads-dashboard.html/<recurso>/`), nada de maquetas. Se nombra a quién se le da y cómo se pide.

## 4 · Vlog / evento
Montaje de tomas sueltas del evento (llegada, lugar, escenario, premiación, equipo, detalles) con voz en off de Gabriel o Dayana. Duración: 60–95 s.

- **Cortes** cada 1.5–3 s, al ritmo de la locución. Cada toma muestra lo que se está nombrando (el campus cuando dice «campus», el jurado cuando dice «jurado»).
- **Subtítulo** de 1 palabra en minúscula, Montserrat 800 blanco pequeño, centrado. Los nombres propios y las palabras clave van GRANDES en Bebas Neue blanca, en mayúsculas: «CIVIL 3D CHALLENGE», «INGENIERÍA», «RENÉ RODRÍGUEZ».
- **Agradecimientos** con nombre y cargo correctos. Comprobar la ortografía de cada nombre con Dayana antes de exportar; Whisper los escribe mal.
- Música de fondo suave, que baja bajo la voz. Sin CTA de venta: cierra con la frase de marca («Seguimos construyendo el futuro de la ingeniería…») y el logo.
- Para orgánico se pueden intercalar tomas de respiro del B-roll «Dopamina» (ver Caja de efectos).

## 5 · Concepto 3D (sin presentador)
Un proceso técnico explicado paso a paso con imágenes o clips 3D generados con IA (Higgsfield u otro), con voz en off. Duración: 30–40 s.

- **Estética de marca en las imágenes:** acero navy, detalles cobre, concreto claro, fondo de obra desenfocado. El último tramo pasa a un holograma navy con líneas cobre, que es el tramo de marca.
- **Un plano por paso** del proceso (p. ej. pernos de anclaje → placa base → nivelación → conexión terminada), con un empuje lento de cámara en cada uno.
- **Subtítulo** de 2–4 palabras en mayúsculas, centrado abajo, blanco, con la palabra clave en caja navy.
- **Logo** «Design Modeling DG» pequeño y fijo arriba.
- **Cierre:** 2–3 s de una clase o un alumno real («aplicado a proyectos reales»), para que no todo sea generado.
- Rotular «Imagen generada con IA» si va en pauta.
- La técnica tiene que ser correcta: Gabriel revisa el guion antes de generar las imágenes.

## 6 · Publicitario
Gabriel a cámara (exterior con cielo, oficina con branding DMA, o casco y camisa DMA) dice un gancho fuerte, con cortes a pantalla y B-roll. Duración: 30–45 s.

- **Gancho** dicho en el primer segundo y escrito arriba, fijo: «Si diseñas cimentaciones sin saber esto, estás en riesgo», «Si quieres trabajar dos veces más rápido en Revit, mira esto».
- **Cortes** a pantalla real (Revit, planos, Robot) o B-roll cada ~2 s. Gabriel recortado sobre la pantalla (segmentación) cuando habla del software.
- **Subtítulo** de 1 palabra en MAYÚSCULAS dentro de una caja cobre, centrado a media altura.
- **«Tip clave»** como rótulo cuando llega el consejo.
- **Cierre:** «Guarda este video», «Sígueme» o «Comenta PALABRA», más 1–2 s de logo.
- **Si es pauta pagada:** aplicar la ficha de anuncios de `patrones-virales-dma` (banda fija con la oferta abajo, 3–4 variantes de gancho, persona real).
- **Variante «bandas fijas»** (estructura de un anuncio de la competencia que lleva 1 año activo, analizado con `clonar-anuncio` el 1-nov-2026): Gabriel recortado abajo a la derecha sobre la pantalla real de Revit, banda fija arriba («WORKSHOP GRATIS») y abajo (producto · fecha · hora) todo el video, pocos cortes (el ritmo lo da el fondo), la objeción antes del botón y cierre personal («nos vemos el martes»). Pieza `nov-ads-ws-taller-gratis` de la matriz.
- B-roll de stock: solo con licencia, y nunca personas que parezcan alumnos si no lo son. El B-roll «Dopamina» NO va en pauta.

## 7 · Testimonio y clase
Prueba social de que lo que se promete se da. Hay tres formatos:

- **Fragmento de clase (DTJlMHiCczr, DXFN853gdXg, DKIoScIhCRr):**
  - la grabación real de la clase (Zoom o pantalla horizontal), centrada en el 9:16;
  - arriba, un marco con el programa («MÁSTER BIM+IA», bandera y sello) y abajo la franja de avales y logos de certificación;
  - subtítulos blancos en 2–3 líneas, o de 1 palabra en mayúsculas si Gabriel está en la pizarra;
  - se elige un momento que se entienda solo, de 30–60 s, con una idea completa;
  - los clips salen de Vimeo con la skill `clips-clases-vimeo`.
- **Certificados y titulaciones (DRuToFvkXTk):** scroll por la página real de certificaciones, con zoom a cada diploma y su sello. Subtítulo blanco con contorno, y palabras clave sueltas grandes («TODO», «UNA», «OBTENER»).
- **Alumno en video (DRhcAwNFYXJ):** la llamada real del alumno mostrando su diploma, con un zoom suave a su cara y al documento y subtítulos de 1–2 palabras en caja cobre. Nombre y país del alumno rotulados.

**Permisos:** solo alumnos que dieron permiso de publicación. Sin datos personales en pantalla (correo, teléfono, número de documento): desenfocarlos.

## 8 · Motion graphics
Aprobado por Dayana (12-oct-2026) dentro de las reglas de siempre: marca DMA, solo material real, gancho en 2 s, Máster sin precio, Acero con $225 solo en pauta y correo. Usa **springs** (física de resorte) en vez de easing fijo. Presets: dry {damping 26, stiffness 180}, standard {18, 120}, heavy {22, 70, mass 1.6}, playful {10, 150, mass 0.8}. En Remotion: `spring()`.

**(a) Gabriel + motion graphics** (el formato para pauta: la persona real que pide la ficha de anuncios + el ritmo del motion):
- **Capas, de abajo arriba:** fondo real → gráficas «detrás» (palabras gigantes, cifras) → Gabriel recortado → gráficas «delante» (chips, tarjetas, logos) → gancho fijo arriba, subtítulo y banda de oferta. Las palabras gigantes van entre y ≈ 320 y 760, para que la cabeza de Gabriel las tape en parte (ese es el efecto de profundidad).
- **Recorte de Gabriel:** lo más rápido es `matte.py` de la plantilla del estilo 10 (MediaPipe). Alternativa: `rembg` con el modelo `u2net_human_seg` (se instala con `pip install --break-system-packages "rembg[cpu]"`; el modelo baja de GitHub). Máscara por fotograma a 540×960 con `only_mask=True` (~1,5 s por fotograma; dos procesos en paralelo; un video de 34 s tarda ~25–30 min, así que se arranca en segundo plano mientras se escribe la composición). Se compone en un WebM VP9 con alfa: máscara escalada a 1080×1920 con `gblur=sigma=1.6`, `alphamerge`, `-pix_fmt yuva420p`; en Remotion va con `<OffthreadVideo transparent>`. El fondo y el recorte comparten exactamente la misma transformación de encuadre (escala y desplazamiento).
- **Fondo:** el real oscurecido con un velo navy (0,35–0,72), o sustituido por B-roll real de la carpeta de Drive (renders de acero, naves, cimentaciones) en los tramos donde se habla de eso, dentro de un `<Sequence>` para que arranque desde su inicio.
- **Delante:** chips en caja cobre/navy/rojo que entran con resorte desde el lado; tarjetas reales (factura con cifra «(ejemplo)», logos del software que enseña el programa sobre placa navy); carita triste para «tu cliente». Nada delante de la cara: chips y logos entre y ≈ 900 y 1400.
- Subtítulo de 1 palabra, sobre caja navy con borde cobre, a media altura (y ≈ 1480), por encima de la banda.
- Cierre: navy + logo DMA + «ESCRÍBENOS» + logo Autodesk Authorized Training Center.

**(b) 100 % animado (Brag / brag-slim)** — para historias, LinkedIn, retargeting y el lanzamiento de cada recurso (no para pauta en frío):
- Flujo: inspeccionar (si es una web nuestra, su código real) → `brag-plan.md` con la rúbrica y el storyboard → construir → revisar fotogramas de cada escena y de mitad de transición → render → mejor fotograma como portada horneada en el frame 0 (sin cambiar la duración) → `share-copy.txt`.
- Forma: gancho 2–3 s → reveal 2–4 s → 2–3 highlights → cierre; 18–22 s. Cortes en el beat de la música.
- **La web real dentro de un celular:** la página va en `<IFrame>` con viewport del tamaño de la pantalla del teléfono; el desplazamiento se hace con `contentWindow.scrollTo({behavior:"instant"})` en cada fotograma, y las posiciones de tarjetas y chips se miden DENTRO del iframe al cargar (`getBoundingClientRect` + `delayRender`/`continueRender`), nunca a ojo. Fuentes y logos remotos se copian locales antes de renderizar (el Chrome del render no siempre llega a Google Fonts ni al CDN de GHL).
- La música que trae Brag no tiene licencia verificada: para pauta, biblioteca de sonido de Meta o música licenciada.

## 9 · Pizarra dibujada (voz de Gabriel con IA)
Aprobado por Dayana el 19-oct-2026 («está genial»), con «5 tipos de cimentación»; versión con letras de marca: «Simbología de niveles en planos» (corte de capas que crece página a página, `escenas-niveles.ts`). Sin presentador: dibujos técnicos que se trazan solos sobre papel mientras la voz explica. Duración: 30–40 s. Plantilla y motor: `video-recursos/plantillas/pizarra-dibujada/` (Remotion).

- **Guion:** una frase por escena, cortas y concretas (patrón: portada → un tipo/paso por página → «¿cuál te toca?» con los criterios → CTA con palabra viva de la matriz). Cada página dura lo que dura su frase.
- **Voz:** Gabriel con IA, aprobado por él (19-oct-2026). Chatterbox Multilingual (MIT, CPU, gratis; `voz_clonada.py`) con 15–20 s de clips suyos limpios como referencia (la muestra nunca va al repo). Una frase por archivo, sin pausas internas de más de 0,1 s, atempo 1.12, 0,1 s entre frases, −14 LUFS; comprobar con Whisper que cada frase dice el guion exacto (las siglas se escriben como se leen: «Ene pe te» para NPT). Higgsfield también clona (seed_audio), pero gasta créditos.
- **Dibujo:** isométrico (`iso` + `box` de `draw.ts`) o en corte: contorno navy `#0D1E3A` de 5 px con temblor de mano, y las caras se rellenan al cerrarse el contorno. Columnas en azul `#004A70` (tres tonos), concreto en grises azulados, terreno en cobre claro con canto `#D78631`, flechas de carga y acentos en cobre `#C8721E`. Letras de marca: títulos y códigos en Bebas Neue navy (la línea de apoyo en cobre), etiquetas en Montserrat 800 dentro de un recuadro dibujado a mano, y «n DE 6» en Montserrat gris arriba. Papel blanco frío con cuadrícula de 60 px.
- **Variante isométrica sin voz** («6 uniones viga de acero a columna de hormigón», 22-oct-2026): render 3D propio en Python (z-buffer a 2×, bordes por cambio de cara, columna de hormigón translúcida con armadura), una pieza distinta cada compás con nombre en caja cobre, música enérgica sincronizada y CTA con la palabra viva.
- **Portada:** fotograma 0 ya dibujado (título grande + 3 de los elementos dibujados con su nombre), sin marcador ni subtítulo, todo dentro del recorte 3:4 del perfil; mientras arranca la voz se escribe encima un subtítulo cobre («y cuándo usar cada una»).
- **Marcador:** cuerpo navy con franja cobre «DMA»; la punta sigue el trazo o la escritura y se levanta entre trazos.
- **Páginas:** cada escena es una hoja nueva que entra deslizando la anterior (0,32 s) con sonido de papel.
- **Subtítulos:** 1–2 palabras en Bebas Neue blanco de 86 px sobre caja cobre `#D78631`, abajo (y ≈ 1630); el logo DMA oscuro va al pie.
- **Música:** la original de `musica_original.py` a `volume=0.13` bajo voz y SFX.
- **SFX:** `scr_marker` en cada tramo que se dibuja, `paper` en cada página y `ding` en la palabra del CTA (`sfx_desde_escenas.py` + `sfx_mix.py`), unos 15 dB por debajo de la voz.
- **Técnica correcta:** los dibujos son esquemas; si hay cifras o normas, Gabriel revisa el guion antes.

## 10 · Gabriel motion cromado (pauta)
Aprobado por Dayana el 22-oct-2026 («está genial para los videos de pauta», con los colores de la empresa). Referencia externa: un reel de un contador con texto cromado y transiciones (se adaptó el lenguaje, no textos ni logos). Plantilla: `video-recursos/plantillas/gabriel-motion-cromado/` — el motor `Motion.tsx` no se toca; por cada crudo solo se escribe `guion.ts`. Duración: la del corte de voz (15–35 s).

- **Recorte de Gabriel:** `matte.py` (MediaPipe *selfie multiclass*, ~1,5 min por 14 s, mucho más rápido que rembg) → `public/<base>_alfa.webm` con alfa; rellena los huecos interiores (camisas claras a rayas se confunden con el fondo). Fondo y recorte con la misma cámara.
- **Palabras clave en cromo 3D** (Bebas Neue, canto extruido de 12 px y sombra): `cobre` para la principal, `navy` con contorno blanco para la de apoyo, `blanco` solo sobre fondo navy. Una o dos por frase, entran con resorte desde 1,9× y desenfoque. **Detrás** de la cabeza a la altura de la frente (y ≈ 420–520), que se lean a los lados; **delante** al pecho (y ≈ 1250), nunca sobre la cara.
- **Palabras pequeñas:** Montserrat 800 cursiva en naranja `#E8893A` con sombra navy, palabra por palabra con desenfoque, arriba (y = 300) o encima de la palabra de delante. El texto cinético hace de subtítulo: no se añaden subtítulos aparte.
- **Íconos 3D:** placa blanca brillante con borde cobre y glifo navy/cobre (pregunta, foco, código, archivo numerado, flecha, check, gráfica, dinero), rebotan al entrar y flotan. Nunca logos de terceros (Meta, Google, TikTok…) salvo el software que se enseña.
- **Transiciones:** zoom con desenfoque + destello blanco (whip) en un cambio de idea; cortina de puntos navy/cobre que lleva a un **estudio navy** con un ícono grande y una frase (1–1,5 s, la voz sigue); destello cobre para volver; golpe de zoom con temblor en la palabra fuerte («HOY»); zoom hacia fuera (1,2 → 1,0) al abrir una idea; contador circular 0 → 100 % («✓ LISTO»).
- **Portada:** fotograma 0 con el título en cromo navy detrás de la cabeza, el subtítulo en cromo cobre al pecho y un chip navy con borde cobre, todo dentro del 3:4.
- **Audio:** voz del editado + `musica_energica.py` (`MUSIC_GAIN=0.16`) + SFX (`sfx_mix.py`, `SFX_GAIN=0.45`): whoosh en la portada, stamp/thud en cada cromo, pop en íconos, slap en el whip, riser + sparkle en la cortina, shimmer en el destello, boom en el golpe, ding al 100 %. Compresor y `loudnorm` −14 LUFS.

## 11 · Ruta de producto («tipo Duolingo»)
Aprobado y en pauta (oct-2026): «La ruta del Máster» v3 (fusión del look de marca de la v1 con las animaciones de la versión «cine»), Colección Autodesk con IA (12 cursos), Especializaciones, Especialización Acero y Diplomado BIM en Cálculo Estructural (5 módulos). Se entrega SIEMPRE en Reel 1080×1920 y YouTube 1920×1080. Duración 45–75 s. El del Máster se incrusta además en el mensaje de bienvenida tras el formulario.

- **Fondo:** navy `#0D1E3A` con cuadrícula fina y viñeta; acentos cobre `#D78631`.
- **Estructura:** gancho (fila de 3 etiquetas + meta, `HookRow`) → un **paso por módulo/curso** (`StepCard`: número, kicker, título y chips con los logos reales del software) unidos por una **línea de luz** que viaja de nodo a nodo (`LightLine`) → carrusel de lo que incluye (`Carousel`: Tutor IA, 1 a 1, MasterClass) → certificados reales que aparecen con `Pop` → `Finale` con la meta, CTA y logo Autodesk ATC.
- **Animación (de la versión «cine»):** cada escena entra con `Whip` (barrido con desenfoque), estallido cobre (`Burst`) al llegar a cada meta, tarjetas de vidrio (`Glass`), resortes `spring` damping 14 / stiffness 160. Foco: lo que no se nombra se oscurece con un velo, para que nunca se encimen etiquetas.
- **Material real, nunca inventado:** logos de software (`AppTile`: Revit recortado al ícono, Navisworks, Dynamo, Python, Robot, Advance Steel, AutoCAD, OpenAI), microcredencial e insignia DQ, certificados de muestra (DM, Autodesk, DQ, Sabal, UDN) con el nombre del alumno y el número **desenfocados** y rotulados «ejemplo», grabación real del Tutor IA. Todo sale de `Logos de Marcas` del Drive o de la web.
- **Voz:** Gabriel con IA (Chatterbox, `voz/tts.py` → `voz/armar.py <clave>` que pega frases, quita silencios y saca los tiempos por palabra con Whisper). Palabras que la voz pronuncia mal se escriben como se leen: «Páiton» para Python (en inglés), «Bim más I A», «Escríbenos y pide información» (evita «pilla»). Revisar con Whisper cada frase.
- **Sincronía:** cada nodo se enciende con su palabra usando raíces cortas que Whisper sí escribe igual (p. ej. «coordinas», no «coordin»; cifras como dígitos «5», «120», «200»).
- **Kit:** `video-recursos/plantillas/motion-dma/src/rutas/kit.tsx` en el repo de la matriz (`makeTiming`, `useStage`, `Whip`, `LightLine`, `Burst`, `Glass`, `AppTile`, `TextTile`, `Pop`, `Hero`, `StepCard`, `Caption`, `Carousel`, `Finale`, `Frame`, `HookRow`); su README dice qué material va en `public/` (no se sube al repo, que es público).
- **Reglas:** el Máster nunca lleva precio; logos solo del software que el programa enseña; en la matriz, evitar «Acero» o «Cursos» en el campo `producto` (activa la etiqueta de precio Black Friday).

## 12 · Cromado con cámara (pauta o historia con tomas reales)
Referencia externa: anuncio IG DeuJ5Z5A3YH (ángulos, zooms, texto e íconos cromados, flash). Prueba DMA «Workshop cromado v2» (31-oct-2026), corregida por Dayana: nada tapa su cara y letras del perfil. Usado también en la historia «Halloween últimas horas» (1-nov-2026, `Story.tsx`). Úsalo cuando hay tomas reales de Gabriel y no hace falta recortarlo.

- **Cámara virtual por toma:** cada plano tiene escala inicial→final (1,0→1,18 o al revés), desplazamiento x/y, leve rotación (±2–4°) y a veces giro en Y para simular otro ángulo. Un plano dura 2,5–4 s; se puede partir la misma toma en dos con encuadres distintos para que parezcan dos cámaras. Con un solo plano fijo (video de celular), golpes de zoom en las palabras fuertes y un tramo más cerrado (+8 %) para disimular los empalmes.
- **Transiciones:** `Whip` (barrido con desenfoque de movimiento) entre planos; **flash blanco** de 3–4 fotogramas en el golpe de la música o la palabra fuerte; un golpe de zoom con temblor como mucho una vez.
- **Texto cromado letra a letra:** Bebas Neue, relleno en degradado suave (blanco → gris claro, o naranja `#F4A35C → #E8893A → #D9772A`), cada letra entra con resorte y desenfoque escalonado ~2 fotogramas; kicker en Montserrat 800 con espaciado 4 encima. Va por debajo del mentón (y ≈ 1290) o, si es portada, encima de la cabeza y nunca más abajo de la barbilla.
- **Íconos o chips:** placas de ~200 px con glifo en relieve, o chips de Bebas Neue navy/naranja que entran uno por uno con su palabra, a los lados o encima de la cabeza, lejos de la cara.
- **Cierre:** tarjeta navy con el CTA en cromo («COMENTA PALABRA») + fecha/oferta en Montserrat + logo DMA; en historias, «TOCA EL ENLACE» con flecha que rebota hacia el hueco del sticker (y ≈ 1590–1720).
- **Audio:** whoosh en cada whip, impacto en el flash, pop en cada chip, música enérgica baja bajo la voz.

## 13 · Motion con IA (imagen 4K → animación Seedance)
Técnica de la comunidad de editores (doc «Prompts de motion graphic con IA», 31-oct-2026). Sirve para ganchos de 2–4 s, B-roll de producto, cierres y fondos de web (p. ej. el edificio que se arma de la portada de la web, 1-nov-2026, 12 s con Seedance 2.0 Mini a 720p por 12 créditos). Se monta luego en Remotion con la voz y la marca.

1. **Imagen de referencia 4K:** prompt estructurado (JSON) que describe el objeto de marca —squircle de app, certificado, ícono del Tutor IA, edificio— en navy/cobre con brillo suave, fondo limpio. **Sin logos en el prompt** (los logos se ponen después en edición).
2. **Fotograma inicial editado:** la misma imagen con el objeto movido abajo o fuera de cuadro (y la interfaz alrededor oculta), o la imagen final como `end_image`.
3. **Animación:** Seedance 2.0 (Higgsfield) con primer fotograma = paso 2 y último = paso 1; prompt: el objeto entra hasta su sitio con ease-out, y luego las piezas de interfaz aparecen escalonadas con fundido y escala, 2–3 s, cámara fija.
- **Costo:** consultar con `get_cost` y decir siempre los créditos de Higgsfield antes de generar y esperar el «sí»; nunca comprar créditos.
- Rotular «Imagen generada con IA» si va en pauta.

## 14 · Isométrico (estilo Anatomy)
Ver skill `explicacion-isometrica-dma`: piezas técnicas en dibujo isométrico que se desarman, se encienden en cobre al nombrarse y se vuelven a armar con la voz de Gabriel, en Reel y YouTube.

## 15 · Efectos Higgsfield (comandos de reel)
Guía tododeia «Higgsfield commands» (5-nov-2026). Son efectos prearmados que el conector de Higgsfield aplica sobre un video vertical de alguien hablando a cámara. Se corren desde esta sesión con el MCP de Higgsfield: `get_preset_instructions` con el comando (p. ej. `/tier-list`) → flujo `reel-effects` (`get_workflow_instructions`) → en su sandbox: `effects.py prepare` + `transcribe` → `build <efecto> --params` → `render --stills` para revisar → `render`. Las plantillas son fijas: se llenan sus parámetros, nunca se reescriben ni se cambian sus letras.

| Comando | Qué hace | Costo | Límite | Cómo se usa en DMA |
|---|---|---|---|---|
| `/tier-list` | Tablero de ranking debajo de la cara; cada ítem cae en su fila, con su logo, cuando se nombra | Sin créditos | 12 ítems, 4 por fila | Gabriel rankea software, métodos o errores («S Revit; A Robot, Advance Steel; B…»). Filas y orden = lo que él dice; nunca un ranking inventado. Logos de terceros solo en orgánico. |
| `/glass-graph` | Tarjeta de vidrio con una gráfica que sube del valor inicial al final cuando se dice la cifra | Sin créditos | 6 por clip | Solo cifras reales (resultados medidos, datos de alumnos con permiso). `color: #E8893A`. |
| `/over-the-shoulder` | Dos tarjetas, antes y después, detrás del hombro (silueta recortada) | Recorte de silueta (de pago) | 6, 16 caracteres por valor | «Antes: 3 h / Después: 10 min» solo si es un dato real; si es ilustrativo, rotular «(ejemplo)». |
| `/freeze-frame` | Congela con flash en cada punto nuevo: fondo en blanco y negro y la persona a color como sticker con etiqueta | Recorte de silueta | 8, ~5 s entre uno y otro | Presentar a Gabriel («GABRIEL PANTOJA», rol «CEO · DESIGN MODELING») o marcar cada paso/tipo que nombra. |
| `/text-behind` | Palabra gigante detrás de la cabeza en cada frase | Recorte de silueta | 12 palabras, 24 caracteres | Versión rápida del «detrás de la cabeza» del estilo 10. `color` blanco o `#E8893A`. Es lo único que puede quedar a la altura de la cabeza, porque va DETRÁS. |
| `/captions` | Subtítulos sincronizados (spotlight, cascade, classic) | Sin créditos | Primer minuto | **No se usa en DMA:** trae su propia letra (League Gothic/Inter), no la del perfil. Los subtítulos salen de `reel-remotion-dma` en Bebas Neue. |
| `/grade-wipe` | Barrido de luz al inicio y luego color de cine (cálido, sombras azules, viñeta) | Sin créditos | 1 por clip | Siempre con `labels: false` (sin «antes/después»). Revisar que la piel de Gabriel quede natural. |

- **Combinar:** varios comandos en un mismo mensaje van al mismo video, con un orden de capas fijo (grade-wipe → text-behind → over-the-shoulder → tier-list → glass-graph → freeze-frame). Un solo estilo por video: `clean` (por defecto) o `bold` en DMA; `neon` y `red` no son de marca. Para cambiar algo se rehace solo ese efecto, sin volver a recortar la silueta.
- **Entrada:** el clip ya cortado con `/editar` (voz limpia, Gabriel a 1,2×), vertical, de 60 s como máximo: solo usa el primer minuto y lo deja en 1080×1920 a 30 fps.
- **Costo:** el único paso de pago es el recorte de silueta (`remove_background` del video; uno por clip sirve para todos los efectos que lo piden). Decir los créditos antes y esperar el «sí»; nunca comprar créditos. Los otros efectos se renderizan sin créditos.
- **Lo que se añade después** (Remotion o ffmpeg), porque los efectos no lo traen: portada de marca en el fotograma 0 y su JPG, subtítulos en Bebas Neue, logo DMA, música propia baja bajo la voz y `loudnorm` −14. Los sonidos de los efectos son CC0 (sirven en pauta); con `render --no-sfx` se quitan.
- **Revisión:** en las stills, nada encima de la cara de Gabriel salvo la palabra de `text-behind` (que va detrás), textos entre x = 120 y 960, nada en el 20 % de abajo, sin huecos en el recorte del pelo ni de la ropa oscura.
- **Letras:** los efectos usan League Gothic e Inter, no Bebas Neue y Montserrat. La primera vez que se use un efecto en una pieza que se publica, Dayana aprueba el look con una prueba; si no le gusta, se hace el equivalente en Remotion (estilos 8, 10 y 12).
- **Nada inventado:** rankings, cifras y antes/después salen de lo que dice Gabriel o de datos reales; si el mensaje y la voz no dan un valor, se pregunta.
- **Del mismo conector:** `/katana` (edición completa de una grabación larga: cortes, subtítulos, animaciones) y `/genjutsu` (pasar los movimientos de un video a otro personaje) gastan créditos: costo primero y esperar el «sí». Para el corte de voz, el flujo de DMA sigue siendo `/editar`.

---

## Caja de efectos (comunidad de editores, 31-oct-2026)
Recursos de la lista «Comunidad Gratuita Editores High Ticket» que Dayana aprobó. Los proyectos .aep y los plugins son de After Effects: aquí se replican en código (Remotion) y con la marca DMA; a Daniela le sirven tal cual si edita en After Effects.

| Efecto | De dónde sale | Cómo se hace en DMA | En qué estilos |
|---|---|---|---|
| **Vidrio (glass panel)** | «7. Glass Panel.aep» | Tarjeta con `backdrop-filter: blur(18px)`, fondo blanco 8–12 %, borde 1,5 px blanco 25 % + brillo diagonal que cruza una vez al entrar; sombra navy suave. Componente `Glass` del kit. | 8, 11, 12, 3 |
| **Reflejo** | «Proyecto Reflejo.aep» | Copia del elemento volteada en Y debajo de él, opacidad 0,25 → 0 con máscara de degradado y 2 px de desenfoque; o una franja de brillo que barre texto/ícono cromado en 0,4 s. | 10, 11, 12, cierres |
| **Texto letra a letra** | plugin Text Evo (.jsxbin) | Cada letra con su propio `spring` desfasado 1–2 fotogramas: entra con desenfoque 12 px → 0, subida 20 px y escala 1,3 → 1; variantes: por palabra, desde el centro, aleatorio. | 10, 12, portadas |
| **Flash** | video «Flash» | Capa blanca (o cobre) a pantalla completa 0 → 0,9 → 0 en 3–4 fotogramas, en el golpe de la música o el cambio de idea; máximo uno cada 4–5 s. | 10, 12, 6 |
| **Dopamina (B-roll cinematográfico)** | carpeta «Dopamina» (100 clips verticales) | Tomas de 0,8–1,5 s intercaladas en los cortes, bajo la voz, para ritmo y emoción. **Solo orgánico, nunca pauta** (no tienen licencia; Dayana asume el riesgo en orgánico, 31-oct-2026). | 1, 4, reels motivacionales del Máster |
| **Plugins AE** (Animation Composer, Motion Tools, Keyframe Wingman, Overlord, Text Evo) | doc «Plugings» | Equivalentes en Remotion: presets de `spring`, `interpolate` con `Easing.bezier`, SVG importado como componente. Recomendarlos a Daniela si edita en AE (muchos gratis). | — |
| **Comandos Higgsfield** (/tier-list, /glass-graph, /over-the-shoulder, /freeze-frame, /text-behind, /grade-wipe) | guía tododeia «Higgsfield commands» | Ver estilo 15: efectos prearmados sobre la toma vertical de Gabriel, luego marca DMA encima. | 1, 6, 10, 12 |

**B-roll «Dopamina» — uso:**
- Bajar la carpeta pública `1oGykifWzDRwC-crNSAhOmSRoTblUKt4h` (listado con `curl https://drive.google.com/embeddedfolderview?id=<id>`, cada archivo con `drive.usercontent.google.com/download?id=<ID>&export=download&confirm=t`). Son ~370 MB: borrar lo que no se use si el disco va justo.
- Encajan con DMA: escritorio/estudio a1, a2, a5, a6, a48, aa6, aa12, aa17; arquitectura/ciudad a12, a61, a43, a36, aa11; cámara y detalle a4, a19, a62; esfuerzo y foco a18, a55b, a44, aa2, aa9, a16; «el camino» a3, a9, b14, a46, a59; impacto/transición aa15, b1, b20, a29, aa14, a20; paisaje de respiro a7, a8, a10, a15, a25, a47, a58.
- **No usar:** escenas de películas o actores famosos (a34, a49, b11, a22, a26), clips con marca de agua de otro creador (p. ej. «Project50»: se descartan, no se recortan) y clips con marcas visibles (autos Porsche a52/a53/a54/b10, lata aa3).
- Que nunca sean más del 20–25 % del video y que no compitan con Gabriel ni con el material real de DMA.

## Recursos de Drive para los videos
Carpeta `PLANIFICACIONES INTERNAS / Contenido Adicional` (id `1xs8oN3qcszkczzGjVl4uBGf2l4zPnf9B`), 921 archivos, ~7,4 GB. Los archivos están compartidos por enlace y bajan con `curl -sSL "https://drive.usercontent.google.com/download?id=<ID>&export=download&confirm=t"`; el índice con los ids ya está en esa misma carpeta del Drive, partido en `manifest-recursos-video-parte-1..18.tsv` (se pegan en orden y se pasan a `video-recursos/scripts/bajar_recursos.py --manifiesto`); si se suben archivos nuevos, se regenera con el conector de Google Drive (`parentId = '<id>'`, recursivo, paginando: la raíz tiene más carpetas en la segunda página). Ese índice nunca se sube al repo, que es público. Lo útil:
- `Material de Diseño Gráfico/Logos de Marcas/` — Autodesk (Revit, Robot, Advance Steel, AutoCAD, Navisworks, Inventor; lockups blanco/negro e iconos), CSI (Etabs, Safe, SAP2000), Cype, Dynamo, Python, OpenAI, Idea Statica, logos ATC y Learning Partner, convenios y sellos (DQ, Sabal, Uninaciones, ISTE, UAIII, EQS), logo DG 2026.
- `MATERIAL PARA VIDEOS 2026/` — B-roll vertical: Acero y naves industriales, cimentaciones, BIM para Máster/Diplomado, «videos de fondo para demostrar validez», títulos y software.
- `Material de Diseño Gráfico/Instructores/` y `Gabriel Pantoja/` — fotos de Gabriel en alta; `Imagenes de Autodesk/` — material oficial de producto; `Cierre de Video Reels/` — cierres de marca.
- `2025-Historias Recurrentes/Testimonios/` — testimonios de alumnos (respetar permisos de publicación).
- Software por producto: Acero = Revit, Robot y Advance Steel (4 certificaciones oficiales de Autodesk). Usar el logo de un software solo si el programa lo enseña.

---

## Estilo A · Tutorial pantalla (base técnica de referencia)
Referencia externa aprobada: https://www.instagram.com/reel/DeKwl3LTg7a/ (30 s, voz en off, ~260 palabras/min).
- **Fondo:** navy muy oscuro (#0A1624) con cuadrícula fina gris al 15% (celdas ~48 px) y viñeta suave.
- **Texto = subtítulo = titular:** centrado. Palabra de apoyo pequeña (Montserrat 800, ~44 px) + palabra clave grande (Bebas Neue, ~150–190 px), en blanco; una palabra clave por bloque en naranja.
- **Entrada con desenfoque:** de `blur(14px)` a nítida en ~0.15 s, con subida de 10 px. Sin rebotes.
- **Capturas reales en tarjeta blanca:** esquinas 14–18 px, sombra grande, 60–75% del ancho, escala 0.92→1 en 0.2 s.
- **Señalar:** rectángulo rojo de 5 px + flecha roja curva que se dibuja en 0.3 s.
- **Íconos de software**, solo de forma genérica y con licencia libre.

## Estilo B · Pizarra + presentador
Referencia externa: https://www.instagram.com/reel/DeKDqymhr5B/. La versión DMA aprobada, con código, es la skill `reel-animacion-explicativa`.

## Primer paso de todo reel · /editar (crudo → voz editada)
Antes de cualquier estilo, el corte de la voz sale de `video-recursos/scripts/editar.py` (repo meta-ads-dashboard.html), que suma lo que proponía la guía tododeia «Editar videos con Claude» (14-oct-2026):
```bash
python3 video-recursos/scripts/editar.py preparar trabajo/ hook.mov d1.mov d2.mov cierre.mov   # → trabajo/receta.json
python3 video-recursos/scripts/editar.py render trabajo/                                         # → gabriel_editado.mp4 + words.json
```
- **Silero** (el VAD que ya trae faster-whisper, `faster_whisper.vad.get_speech_timestamps`, sin instalar nada) decide dónde hay voz; Whisper solo estira los bordes de cada tramo (hasta 0,3 s antes y 0,35 s después) para no comerse finales de palabra, que es lo que fallaba al cortar por volumen. Con el crudo del Pack de Dynamo dio los mismos cortes que se hicieron a mano.
- **Ojo con los tiempos de Whisper en crudos largos** (videollamadas): pueden desfasarse casi 1 s. Cortar siempre por los tramos de voz de Silero y verificar cada corte transcribiéndolo suelto; nunca cortar solo por los tiempos de palabra (testimonio de Mark, 15-oct-2026: se comía frases). Cortar video y audio en una sola pasada para que no se desincronicen.
- **Encuadre a la cara:** si un clip es horizontal (clases, seguimientos, Zoom), YuNet (OpenCV `FaceDetectorYN`, modelo en `~/.cache/dma-video/yunet.onnx`, se baja solo de media.githubusercontent.com) busca la cara en 24 fotogramas y recorta el 9:16 centrado en la mediana. En Zoom, revisar fotograma a fotograma que no salte a la cámara de otra persona (orador activo) y tapar esos instantes con pantalla real o un fotograma contiguo.
- **Receta** `receta.json`: tramos por clip, `velocidad` (1.2 Gabriel, 1.1 clases) y `lufs`. Se edita a mano (quitar una frase, alargar una pausa) y `render` rehace solo los clips cuya parte cambió (caché por huella).
- **Volumen:** loudnorm en dos pasadas a −14 LUFS / −1 dBTP (en voz queda ~−14,5 a −15 por el límite de pico; Instagram no exige un valor oficial).
- Después, el estilo que toque usa `gabriel_editado.mp4` y `words.json` como siempre.

## Cómo aplicar cualquier estilo
- Anclar cada gráfico, captura y corte a la palabra exacta (0–100 ms antes), con los tiempos re-transcritos sobre la voz editada.
- SFX bajos con `sfx_mix.py`: whoosh en los cambios, pop en capturas, `scr_marker` al dibujar; mezcla con `volume=0.13` y `highpass=250`.
- Subtítulos que nunca tapen la cara: si hay cara, van sobre la cabeza (y ≈ 300, o justo debajo de la tarjeta de pregunta) a unos 100 px, o por debajo del mentón.
- Verificar con una hoja de contacto que el texto se lee en el móvil, que nada tapa la cara y que nada queda quieto más de 2–3 s.
- No inventar métricas, comentarios, alumnos ni capturas. Los números de ejemplo se rotulan «(ejemplo)».
- Final: ffmpeg `yuv420p` (con `scale=in_range=full:out_range=tv`), `loudnorm` −14, AAC 192k, `+faststart`.

## Motores
- **Remotion:** motor principal, probado y aprobado. Plantilla de arranque con todo instalado: `video-recursos/plantillas/motion-dma/` (copiar y `npm i`).
- **HyperFrames** (`npx hyperframes`): resultado idéntico, pero unas 2.5 veces más lento en la nube. Solo para piezas sueltas que el equipo quiera retocar sin código.
- **Efectos Higgsfield** (`reel-effects` en el sandbox de Higgsfield): solo los efectos prearmados del estilo 15, sobre la toma vertical de Gabriel; la marca DMA se pone encima con Remotion.
- **Licencia de Remotion:** gratis para personas y equipos de hasta 3; una empresa de 4 o más necesita licencia de empresa (remotion.pro). HyperFrames es Apache 2.0 y Brag MIT.