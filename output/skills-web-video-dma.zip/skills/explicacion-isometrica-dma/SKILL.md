---
name: "explicacion-isometrica-dma"
description: "Videos explicativos DMA en dibujo isométrico técnico (estilo Anatomy): piezas que se arman, desarman y se encienden al ritmo de la voz de Gabriel, en Reel y YouTube."
---

# Explicación isométrica DMA (Anatomy en video)

Para explicar un concepto técnico construyéndolo como un objeto real en isométrico: una conexión viga-columna que se desarma, una zapata con su parrilla, una viga que se arma varilla por varilla, un edificio que se separa por disciplinas BIM, una nave que se monta pieza por pieza. Responde siempre en español.

Base: el kit de dibujo de **Anatomy** (MIT, https://github.com/wheresryan22/anatomy) — cámara isométrica, sólidos con sombreado de 4 tonos, piezas torneadas y pernos — usado dentro de Remotion (estudio de Motion Architect + kit de rutas DMA). Anatomy está hecho para figuras web interactivas; aquí lo usamos para video, con el movimiento anclado a la voz.

Cuándo usarlo: explicaciones técnicas donde ver las piezas ayuda (conexiones, armado, capas, montaje). No para todo: cada objeto se modela pieza por pieza y toma más tiempo que un reel normal.

## 1. Preparar (una vez por sesión)
```bash
git clone --depth 1 https://github.com/wheresryan22/anatomy.git <scratch>/anatomy
mkdir -p ~/motion-architect/studio/src/anatomy
cp <scratch>/anatomy/kit/iso-kit.mjs <scratch>/anatomy/kit/lathe.mjs <scratch>/anatomy/LICENSE ~/motion-architect/studio/src/anatomy/
```
- En `studio/tsconfig.json` poner `"allowJs": true` para importar los `.mjs`.
- Leer `references/kit.md` del repo para la API (no hace falta leer todo SKILL.md de Anatomy).
- Renders: `npx remotion render ... --ignore-certificate-errors` (el proxy). Si Chrome no arranca, revisar RAM (la TTS de Chatterbox ocupa ~4 GB: no renderizar mientras genera voz) y disco.

## 2. Guion y voz
- 4–8 frases cortas, una idea por frase, cada pieza nombrada en el orden en que aparece. 12–40 s.
- Voz IA de Gabriel (Chatterbox + `armar.py`, verificación con Whisper). Revisar palabras mal dichas y regenerar esa frase.
- Si Whisper escribe números como dígitos («8», «200»), usar esos dígitos como raíz para sincronizar.

## 3. Geometría (mundo en ~px, z hacia arriba)
```ts
import * as I from "../anatomy/iso-kit.mjs";
import * as G from "../anatomy/lathe.mjs";
// Perfil I vertical (columna): contorno en planta extruido en z, cóncavo
I.extrude(ringI, 0, 760, P, { convex: false, bevel: 0.6 });
// Placas, alas, almas, rigidizadores: cajas
I.slabOf({ x, y, w, d, r: 0 }, z, h, P, 2, 0.6);
// Pernos a lo largo de x: vástago + cabeza hexagonal
const F = G.frameAlong([x0, y, z], [1, 0, 0]);
G.disc(-48, 0, 9, F, P);          // vástago
G.prismOf(F, hexagono, 0, 13, P); // cabeza
// Pintar: I.solidSvg(paths, { lit, tone: "hi", crease: "faint" })
```
- Cada pieza: `{ id, grupo, centro: [x,y,z], svg, svgEncendido }`, construida una sola vez por proyección (`useMemo`).
- Cámara: `I.fitProjection(puntosExtremos, w, h, { pad: 20 })` con los puntos armado **y** desarmado, para que nada se salga.

## 4. Movimiento (por fotograma)
- Desarmar/armar = desplazamiento en mundo por grupo: `I.translateAlong(P, [dx,dy,dz])` como `transform` del `<g>` (no reconstruir geometría).
- Orden de pintado: en cada fotograma ordenar las piezas por `I.depthOf(centro + desplazamiento, P)` ascendente.
- La pieza que se nombra se enciende en cobre (`lit`) mientras se habla de ella; las piezas vuelven a su lugar justo cuando la voz las nombra; los pernos entran escalonados (4 fotogramas entre uno y otro).
- Etiquetas: caja navy con borde cobre + línea guía desde `I.iso(anclaje + desplazamiento, P)`; entran 0–4 fotogramas antes de la palabra.

## 5. Marca DMA (tema oscuro sobre el CSS del kit)
```css
.iso{--anatomy-paper:#132648;--anatomy-face:#1B3560;--anatomy-top:#244274;
--anatomy-shade-0:#0F1F3B;--anatomy-shade-1:#142A4E;--anatomy-shade-2:#19335E;--anatomy-shade-3:#1F3C6C;
--anatomy-lit-top:#F2A95C;--anatomy-lit-shade:#B8681F;--anatomy-lit:#FFE3BF;
--anatomy-hi:#DCE6F5;--anatomy-mid:#9FB0CC;--anatomy-lo:#5C719A;--anatomy-faint:#3A5582;
--anatomy-weight:2.2px;}
.iso-solid[data-lit]>.iso-fill{fill:#C97A2A}
```
- `<AbsoluteFill className="iso"><style>{I.ISO_CSS + ISO_DMA}</style><svg className="iso-svg" viewBox=... dangerouslySetInnerHTML={{__html: cuerpo}} /></AbsoluteFill>`.
- Fondo navy con cuadrícula, logo DMA, Anton/Overpass, música baja bajo la voz y SFX (whoosh al desarmar, bong al encender) con el `Frame` del kit de rutas.
- Reglas de siempre: portada en el fotograma 0 (título completo visible dentro del recorte 3:4, sin animación de entrada), zonas seguras de Instagram, sin silencios, logo DMA, sin precios del Máster.
- Encuadre: vertical, título arriba (~0,2 H) y figura en y 700–1560; horizontal, título a la izquierda y figura a la derecha (x ≥ 760). Comprobar que el título no pise la figura en portada ni en el cierre.

## 6. Verificar y entregar
- Hoja de fotogramas (portada, desarmado, cada pieza encendida, cierre) en vertical y horizontal; mirarla antes de renderizar todo.
- Revisar: piezas que se cruzan mal al pintar, etiquetas cortadas en los bordes, texto encima de la figura.
- Export: loudnorm −14 LUFS, yuv420p, faststart; entregar Reel 9:16 + YouTube 16:9 + portada.
- Si va a pauta: subir a `vimeo-clips/editados/pauta/<id>/` y cargar la pieza en la matriz (PR; mezclar solo con el «mezcla» de Dayana).

## Límites
- Dibuja máquinas, piezas y estructuras; no personas ni mapas exactos.
- Rotaciones alrededor de z no se hacen con transform: reconstruir esa pieza por fotograma.
- Mantener la atribución MIT de Anatomy (LICENSE copiado junto al kit).