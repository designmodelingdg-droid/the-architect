---
name: "reel-animacion-explicativa"
description: "Edición de reels y pautas de DMA con animaciones explicativas: pizarra de cuaderno que se dibuja sobre Gabriel, subtítulo en barra cobre y cierre con el material real del recurso. Úsala cuando Dayana pida \"edición explicativa\", \"con animaciones explicativas\", \"estilo pizarra\" o \"para pauta\"."
---

# Reel con animaciones explicativas (estilo pizarra DMA)

Estilo aprobado por Dayana el 7-oct-2026 con dos reels: «Derivas de piso» (CTA MEMORIA) y «Una IA no sabe cuándo se equivoca» (CTA GUIA). Su reacción: «está brutal», «me encanta». Es la versión DMA del Estilo B de `estilos-reels-dma`, con la paleta de marca. Responde siempre en español.

**Cuándo usarla:** Gabriel (u otro docente) habla a cámara y explica un concepto, un error o un criterio técnico. Sirve para reels orgánicos y para pautas. Para tutoriales de pantalla sin cara, usar el Estilo A de `estilos-reels-dma`.

Usar junto con `reel-remotion-dma`, que tiene el motor: Whisper, cortes, ffmpeg y `sfx_mix.py`. Esta skill define el diseño y la dirección.

## Flujo completo

1. **Material crudo.** Las carpetas de Drive con HOOK / DESARROLLO 1-3 / CIERRE (.mov 4K HEVC de iPhone, rotación -90) se descargan desde la nube sin pasar por el conector: `curl -sSL -o x.mov "https://drive.usercontent.google.com/download?id=<ID>&export=download&confirm=t"`. El ID se lista con `search_files parentId = '<carpeta>'`.
2. **Proxys:** `scale=1080:1920,fps=30`, `loudnorm=I=-16:TP=-1.5:LRA=11`, más un WAV mono 16 k para Whisper.
3. **Transcribir** con faster-whisper `medium`, int8, `word_timestamps`, pasando numpy desde el WAV. Usar un `initial_prompt` con los términos técnicos del guion.
4. **Buscar el guion en la matriz:** `meta-ads-dashboard.html/matriz-viral/matriz/guiones-completos.json` y `calendario-*.json` tienen el guion, la palabra del CTA y las notas de producción (p. ej. «verificar el límite contra la norma»). Respetarlas.
5. **Cortar silencios:** `silencedetect=-38dB:d=0.18`, con 0.06 s de margen. Acotar cada clip entre la primera palabra −0.12 s y la última +0.12 s, para quitar respiraciones y ruido de cola. Concatenar con `afade` de 12–15 ms y aplicar 1.2× (`setpts=PTS/1.2`, `atempo=1.2`).
6. **Re-transcribir la voz editada.** Esos tiempos mandan todo.
7. **Medir el encuadre:** hacer una hoja de contacto cada 3 s y anotar por clip la altura de la cara (`faceY` en px sobre 1080×1920) y la escala. Un plano abierto pide `s` de 1.35–1.45.
8. **Escribir el guion visual:** una lámina por idea, cada trazo anclado a la palabra exacta (0–100 ms antes).
9. **Revisar stills** antes de renderizar todo: una hoja de 10–13 frames clave.
10. **Render:** `--concurrency=2`, porque la nube tiene 2 núcleos. Un reel de 45 s tarda unos 5 min.
11. **Mezclar SFX y exportar:** `highpass=250,volume=0.13`, `yuv420p`, `+faststart`. Re-transcribir el MP4 final para comprobar que se entiende cada palabra.

## El diseño

**Paleta (marca DMA, nunca amarillo):**
- Cobre `#D78631`: barra de subtítulos, etiquetas, relleno de barras.
- Cobre claro `#E8A04A`: palabras gigantes, con contorno navy `#0D1E3A` de 5 px.
- Navy `#0D1E3A`: fondo del cierre.
- Papel `#F4F1E6` con cuadrícula `#CFCAB8` cada 48 px y viñeta interior.
- Tinta `#1B1B1B`, gris de notas `#5A554B`.
- Rojo marcador `#E5252A`: solo para círculos, X, sellos y subrayados.

**Tipografías:** Anton (titulares gigantes), Overpass 800 (palabras pequeñas y subtítulo), Kalam 700 (todo lo escrito a mano). Kalam está en `video-publicidad-dma/assets/pizarra/fonts` (`YA9Qr0Wd4kDdMtDqHTLMkiQ.woff2` latin, `YA9Qr0Wd4kDdMtDqHTLCkiQ4tg.woff2` ext).

**Estructura:**
1. **Gancho a pantalla completa (2–4 s).** La frase del gancho entra palabra por palabra con desenfoque, apilada sobre el pecho: línea pequeña en Overpass 56, línea media en Anton 104–120 y la palabra clave en Anton 170–180 cobre claro, que entra con golpe de escala 1.35→1 y un subrayado rojo que se dibuja debajo. Sombra degradada en la mitad inferior. El cuadro se acerca lento a la cara (+5 % en 6 s).
2. **Pantalla dividida.** La pizarra (960 px) baja desde arriba en 0.32 s mientras el video se reacomoda: la cara queda en y = 1340 (`ty = 1340 − faceY·s`). Gabriel se acerca a 1.08 en cada cambio de frase, para que algo se mueva cada pocos segundos.
3. **Láminas.** Una por idea (4–7 por reel), con el título escrito a mano arriba (Kalam 66–78). Los elementos se dibujan con trazo progresivo cuando se nombran. Al salir, la lámina sube 40 px y se desvanece en 0.2 s.
4. **Subtítulo en la costura:** una palabra (las de ≤2 letras se juntan con la siguiente, salvo «NO») en una barra cobre de 560 px de ancho mínimo y 104 de alto, centrada en y = 960. Letra blanca Overpass 800 de 60 px con contorno navy de 7 px. Solo aparece cuando la pantalla está dividida del todo.
5. **Frase de impacto a pantalla completa** (1–2 s) para la conclusión («ES TUYO», «CORREGIR»): la pizarra se va y la palabra cae grande en cobre claro.
6. **Cierre con CTA y material real** (ver abajo).

**Vocabulario de la pizarra:** recuadros y rectángulos con temblor de marcador, columnas con flechas de carga, pórticos deformados (gris discontinuo contra deformado en negro), robot de línea propio (nunca stickers ni personajes de terceros), burbujas de chat, barras de «seguridad» que se llenan, listas con ✓ cobre y X roja, firma a mano en azul `#1E3A8A`, sellos rojos rotados («SIN VERIFICAR», «RESPONSABILIDAD»), etiqueta cobre («ENTREGADO»), círculo rojo que se pasa un poco de largo y columnas «SÍ para… / NO para…» separadas por una línea fina.

**Honestidad:**
- Cualquier número de ejemplo que Gabriel no dijo se rotula «(ejemplo)».
- Lo que el guion presenta como contenido del recurso (las 3 comprobaciones, las secciones de la plantilla) se copia del recurso real, no se inventa.
- No se inventan métricas, comentarios ni capturas.

## Cierre con material real (lo que más gustó)

El recurso que se promete se muestra de verdad:

1. «COMENTA» (Anton 110) y ««PALABRA»» (Anton 170–190, cobre claro) sobre Gabriel, sincronizados con la voz.
2. Cuando nombra el recurso: fondo navy radial al 88 %, el CTA sube arriba (`translateY(-620) scale(0.72)`) y entra desde abajo un celular (560×1212, borde 14 px `#0A0F1A`, radio 60, girado −3°).
3. Dentro del celular, las **capturas reales del lead magnet** que hay en `meta-ads-dashboard.html/<recurso>/`, publicado en `designmodelingdg-droid.github.io/meta-ads-dashboard.html/<recurso>/`. Se capturan con Playwright: viewport 390×844, escala 2, `is_mobile`, `full_page`. La guía se abre con `?acceso=dm2026`. Orden: landing → scroll de la guía hasta la sección que se nombra → siguiente sección, con fundido de 0.18 s entre imágenes.
4. Una tarjeta blanca girada 3° con la pieza más concreta: la tabla de la plantilla Word (`soffice --convert-to pdf` y luego `pdftoppm -r 220`) o la lista de la guía, con círculo rojo y la etiqueta cobre «PLANTILLA EN WORD».
5. A la derecha, notas a mano que se escriben con la voz: «la guía real / + plantilla Word / + hoja Excel», o «10 errores / + su prompt / + 3 comprobaciones».
6. Alargar 1.5–2 s después de la última palabra y terminar con un ding.

El formulario de GHL no carga desde la nube (sale en blanco). Si se quiere mostrar, pedir a Dayana una grabación de pantalla del celular llenándolo.

**Antes de publicar, revisar la palabra del CTA en la matriz:** quién la contesta (GHL u OpenReply) y que una sola automatización la escuche. En octubre: MEMORIA la contesta GHL; GUIA la contesta OpenReply, con la campaña «Guía Revit».

## SFX (sintetizados con `sfx_mix.py`, siempre bajos)

- `whoosh_in` en 0 s y `whoosh` en cada entrada o salida de la pizarra y cambio de lámina.
- `scr_marker` (0.6–0.75) al empezar cada dibujo y cada círculo rojo.
- `pop` en burbujas y números, `tick` en cada X.
- `stamp` en sellos y palabras que caen; con ganancia baja si coincide con una palabra clave.
- `card` en la tarjeta del recurso y `ding` al final.

## Piezas de código (Remotion 4)

```tsx
const p = (t:number,t0:number,d=0.3,e=EASE)=>interpolate(t,[t0,t0+d],[0,1],{extrapolateLeft:"clamp",extrapolateRight:"clamp",easing:e});
const rnd=(s:number)=>{const x=Math.sin(s*9301+49297)*233280;return x-Math.floor(x);};
// línea con temblor de marcador
const hand=(pts:[number,number][],seed=1,j=3)=>{let d=`M${pts[0][0]},${pts[0][1]}`;for(let i=1;i<pts.length;i++){const[x0,y0]=pts[i-1],[x1,y1]=pts[i];d+=` Q${(x0+x1)/2+(rnd(seed+i)-.5)*j*2},${(y0+y1)/2+(rnd(seed+i*7)-.5)*j*2} ${x1},${y1}`;}return d;};
const rect=(x,y,w,h,seed)=>hand([[x,y],[x+w,y+2],[x+w-2,y+h],[x+2,y+h-1],[x,y-4]],seed,4);
// círculo que pasa de largo
const loop=(cx,cy,rx,ry,seed)=>{const pts=[];for(let i=0;i<=26;i++){const a=-.5+(i/24)*Math.PI*2,k=1+(rnd(seed+i)-.5)*.06+i*.004;pts.push([cx+Math.cos(a)*rx*k,cy+Math.sin(a)*ry*k]);}return hand(pts,seed,2);};
// trazo progresivo: <path pathLength={1} strokeDasharray={1} strokeDashoffset={1-k}/>
// texto a mano: div Kalam con clipPath `inset(-20% ${(1-k)*100}% -20% -2%)`, duración min(0.55, 0.06+0.035·letras)
// presentador: splitAmt(t) en 0..1; s = sFull+(sSplit-sFull)·m; ty = tyFull+(tySplit-tyFull)·m; transformOrigin "50% 0"
```

La plantilla completa y probada está en `/home/claude/raw4/proj/src/Composition.tsx` (reel IA) y `/home/claude/raw3/proj/src/Composition.tsx` (derivas), si la sesión los conserva. Si no, se reconstruye con estas piezas.

## Verificación antes de entregar

- Hoja de contacto del MP4 final cada 2 s.
- Ningún texto de la pizarra en y > 900, donde lo tapa la barra.
- La barra no tapa la cara.
- La cara queda completa en cada clip.
- La palabra del CTA coincide con la matriz.
- Re-transcripción del final idéntica a la de la voz.

## Para pautas

Mismo estilo. Gancho en el primer segundo con la palabra clave grande, y duración de 20–35 s (recortar láminas, no la voz). Si la pieza lleva la cara o la voz de Gabriel generada con IA, marcarla como contenido generado con IA en Meta.