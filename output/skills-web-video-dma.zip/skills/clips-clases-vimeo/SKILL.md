---
name: "clips-clases-vimeo"
description: "Saca fragmentos virales de las clases grabadas de DMA en Vimeo (Gabriel y docentes) y los edita como reels de prueba social para que la gente vea lo que se da en los cursos. Úsala cuando Dayana pida clips de clases, «cachitos» de Vimeo o videos de «lo que damos»."
---

# Clips de clases desde Vimeo

Dayana (7-oct-2026): en Vimeo están todas las clases grabadas de los cursos de DMA. De ahí se sacan fragmentos de los temas más buscados o virales del día, para que la gente vea lo que se da en clase y se anime a inscribirse. Es contenido de prueba social, junto con los testimonios. Responde en español.

Edición: estilo 7 («Testimonio y clase») de `estilos-reels-dma`. Gancho, ritmo y CTA: `patrones-virales-dma`. Motor: `reel-remotion-dma`.

## Acceso a Vimeo (comprobar primero)
1. Buscar un conector de Vimeo en la sesión con ToolSearch o `SearchMcpRegistry` ("vimeo").
2. Si no hay conector, pedir a Dayana un **token personal de la API de Vimeo** con permisos `private` y `video_files`, creado en developer.vimeo.com → su app → «Generate access token». Se guarda solo como variable de entorno de la sesión (`VIMEO_TOKEN`). **Nunca en el repo ni en un archivo.**
3. Con el token:
   - listar: `GET https://api.vimeo.com/me/videos?per_page=100&fields=uri,name,duration,created_time,link,parent_folder.name` (paginar);
   - carpetas: `GET /me/projects`;
   - descargar: el campo `download` o `files` del video (requiere plan Pro o superior y permiso de descarga). Si la red de la nube bloquea `api.vimeo.com` o `vod`, decirlo y pedir que se suba el archivo al Drive.
4. Alternativa sin API: Dayana descarga la clase de Vimeo y la sube a una carpeta del Drive. Desde ahí se baja con `drive.usercontent.google.com/download?id=<ID>&export=download&confirm=t`.

## Encontrar el momento viral
1. **Elegir el tema del día:** cruzar lo que más rinde en el nicho (`patrones-virales-dma`: hoy, IA + Revit) con lo que pide la matriz de la semana (`matriz-viral/matriz/calendario-*.json`).
2. **Elegir la clase:** por nombre de carpeta y título en Vimeo (módulo, curso, sesión).
3. **Transcribir la clase entera** con faster-whisper `small` (rápido) y `word_timestamps`. Las clases duran 1–3 h: procesar por bloques de 10 min.
4. **Puntuar ventanas de 30–60 s:**
   - (a) contiene una idea completa que se entiende sin contexto;
   - (b) tiene una frase-gancho natural (pregunta, error común, «esto es importante», un número, «la mayoría hace X»);
   - (c) hay cambio visual en pantalla (software, pizarra, modelo 3D);
   - (d) sin datos de alumnos visibles, o se pueden desenfocar;
   - (e) el docente suena seguro y no se pierde.
5. **Proponer 3–5 candidatos** a Dayana con: tiempo en la clase, frase de inicio y fin, por qué funciona y el gancho escrito propuesto. **No editar ninguno sin su visto bueno** si el clip muestra alumnos o datos.

## Editar el clip
- **Recorte:** de 30 a 60 s. Se puede quitar alguna muletilla («¿sí?», «¿ok?», «eh») y las pausas largas, a 1.1× como mucho, porque es una clase y debe sonar natural.
- **Marco del programa:** arriba, una banda con el programa al que pertenece la clase («MÁSTER BIM+IA», «DIPLOMADO…») con bandera y sello; abajo, la franja de avales y certificaciones (Autodesk ATC y los que correspondan, tal como los entrega cada emisor). La clase horizontal va centrada, con zoom a la zona útil de la pantalla.
- **Gancho escrito arriba** en los primeros 2 s, fijo: la frase del momento o una pregunta («¿Parámetros de proyecto o compartidos?»).
- **Subtítulos:** blancos en 2–3 líneas debajo de la pantalla, o de 1 palabra en mayúsculas con caja cobre si la toma es de Gabriel en la pizarra.
- **Cierre:** «Esto es una clase real del <programa>» + CTA con palabra viva o «Pide información». Nunca el precio del Máster.

## Cuidados
- **Privacidad:** desenfocar nombres, correos, caras y chats de alumnos en Zoom, salvo los que dieron permiso.
- **Contenido de pago:** un clip enseña una idea, no la lección completa. Como mucho 60 s por clase, y sin repetir el mismo bloque en varios clips.
- **Errores técnicos:** si el docente se equivoca o dice algo que cambió con la versión del software, no se usa ese fragmento.
- Cada clip publicado se anota en la matriz con su fuente (video de Vimeo y minuto) para no repetirlo.